/* ===== এখানে প্রয়োজনে পরিবর্তন করুন ===== */
window.TELTORI = {
  shopPhone: '8801763613445',   // WhatsApp নম্বর (দেশের কোডসহ, + ছাড়া)
  unitPrice: 950,               // প্রতি বোতলের দাম
  maxQty: 10,                   // সর্বোচ্চ কত বোতল অর্ডার করা যাবে
  // Firebase বসালে অ্যাডমিন প্যানেল ও "আমার অর্ডার" সব ডিভাইসে কাজ করবে (README দেখুন)
  firebase: { apiKey: '', authDomain: '', projectId: '', appId: '' }
};
